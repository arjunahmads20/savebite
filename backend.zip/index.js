const express = require('express');
const app = express();
const pool = require('./db.js');
const PORT = 3000;

app.use(express.json());

// ==========================================
// FUNGSI AJAIB: PEMBUAT CRUD OTOMATIS
// ==========================================
const createCRUDEndpoints = (endpoint, tableName) => {
    
    app.get(`/api/${endpoint}`, async (req, res) => {
        try {
            const result = await pool.query(`SELECT * FROM ${tableName} ORDER BY id DESC`);
            res.json(result.rows);
        } catch (err) { res.status(500).json({ error: err.message }); }
    });

    app.get(`/api/${endpoint}/:id`, async (req, res) => {
        try {
            const result = await pool.query(`SELECT * FROM ${tableName} WHERE id = $1`, [req.params.id]);
            if (result.rows.length === 0) return res.status(404).json({ error: "Not found" });
            res.json(result.rows[0]);
        } catch (err) { res.status(500).json({ error: err.message }); }
    });

    app.post(`/api/${endpoint}`, async (req, res) => {
        try {
            const keys = Object.keys(req.body);
            const values = Object.values(req.body);
            const placeholders = keys.map((_, i) => `$${i + 1}`).join(', '); 
            
            const query = `INSERT INTO ${tableName} (${keys.join(', ')}) VALUES (${placeholders}) RETURNING *`;
            const result = await pool.query(query, values);
            res.status(201).json(result.rows[0]);
        } catch (err) { res.status(500).json({ error: err.message }); }
    });

    app.put(`/api/${endpoint}/:id`, async (req, res) => {
        try {
            const keys = Object.keys(req.body);
            const values = Object.values(req.body);
            const updates = keys.map((key, i) => `${key}=$${i + 1}`).join(', ');
            
            const query = `UPDATE ${tableName} SET ${updates} WHERE id=$${keys.length + 1} RETURNING *`;
            const result = await pool.query(query, [...values, req.params.id]);
            if (result.rows.length === 0) return res.status(404).json({ error: "Not found" });
            res.json(result.rows[0]);
        } catch (err) { res.status(500).json({ error: err.message }); }
    });

    app.delete(`/api/${endpoint}/:id`, async (req, res) => {
        try {
            const result = await pool.query(`DELETE FROM ${tableName} WHERE id = $1 RETURNING *`, [req.params.id]);
            if (result.rows.length === 0) return res.status(404).json({ error: "Not found" });
            res.status(204).send();
        } catch (err) { res.status(500).json({ error: err.message }); }
    });
};

// ==========================================
// DAFTAR ENDPOINT API SAVEBITE
// ==========================================

// 1. Company
createCRUDEndpoints('visions', 'visions');
createCRUDEndpoints('missions', 'missions');
createCRUDEndpoints('partners', 'partners');

// 2. Account (Terdapat Pembaruan!)
createCRUDEndpoints('users', 'users');
createCRUDEndpoints('otp-verifications', 'otp_verifications'); // API BARU
createCRUDEndpoints('user-inboxes', 'user_inboxes'); // API BARU

// 3. Address System
createCRUDEndpoints('countries', 'countries');
createCRUDEndpoints('provinces', 'provinces');
createCRUDEndpoints('regencies', 'regencies');
createCRUDEndpoints('districts', 'districts');
createCRUDEndpoints('villages', 'villages');
createCRUDEndpoints('streets', 'streets');
createCRUDEndpoints('pick-addresses', 'user_pick_addresses');

// 4. Goods System (Terdapat Pembaruan!)
createCRUDEndpoints('good-categories', 'good_categories');
createCRUDEndpoints('good-donation-points', 'good_donation_points');
createCRUDEndpoints('user-goods', 'user_goods');
createCRUDEndpoints('user-good-pictures', 'user_good_pictures');
createCRUDEndpoints('good-takens', 'good_takens');
createCRUDEndpoints('good-taken-reviews', 'good_taken_reviews');
createCRUDEndpoints('requests', 'requests'); // API BARU

// 5. Chat System
createCRUDEndpoints('chats', 'chats');

// ==========================================
// SERVER RUNNING
// ==========================================
app.listen(PORT, () => {
    console.log(`🚀 SaveBite Ultimate API is running on http://localhost:${PORT}`);
});